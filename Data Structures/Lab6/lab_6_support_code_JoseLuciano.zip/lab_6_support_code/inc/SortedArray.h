#ifndef SortedArray_h
#define SortedArray_h

#include <iostream>
#include <ostream>



struct SortedArray {
	long* data;

	long capacity;

	long count;

	SortedArray() {
		data = new long[0];
		data[0] = NULL;
		capacity = 0;
		count = 0;
	}


	// This is a copy constructor. It specifies what happens when
	// the array needs to be copied. In this case it performs
	// a deep copy, which is what we need
	SortedArray(const SortedArray& other) {
		capacity = other.capacity;
		count = other.count;
		data = new long[other.capacity];

		for (long i = 0; i < other.count; i++) {
			data[i] = other.data[i];
		}
	}

	void operator=(const SortedArray& other) {
		std::cout << "HI" << std::endl;
		capacity = other.capacity;
		count = other.count;
		data = new long[other.capacity];

		for (long i = 0; i < other.count; i++) {
			data[i] = other.data[i];
		}
	}

	long& operator[](long index) const {
		return data[index];
	}

	// Overloading the == operator. Now we can compare 
	// two SortedArray with the == operator
	bool operator==(const SortedArray rhs) const {
		// If the capacitys or counts are different, it's not a match
		if (capacity != rhs.capacity) {
			return false;
		}
		if (count != rhs.count) {
			return false;
		}

		// Assume the arrays match
		bool same = true;

		// And try to find a contradiction
		for (long i = 0; i < count; i++) {
			if (data[i] != rhs.data[i]) {
				return false;
			}
		}

		// Could not get a contradiction
		return true;
	}


	// THe function has a complexity of O(n) where the best case is O(1) where everything is already sorted and worst case of O(n) where it has to iterate through the entire loop.
	void insert(long num) {
		if (data[0] == NULL) {
			capacity = 1;
			long* temp = new long[capacity];
			temp[0] = num;
			delete[] data;
			data = temp;
			count++;
		}
		else {
			if (count == capacity) { //doubling the array capacity, count at this point should be 1 or more
				long OldCapacity = capacity;
				capacity = capacity * 2;

				long* temp = new long[capacity];


				for (long i = 0; i < OldCapacity; i++) {
					temp[i] = data[i];
				}
				temp[count] = num;
				delete[] data;
				data = temp;
			}
			else {
				long oldcapacity = capacity;
				while (count +1 >= capacity) {
					capacity *= 2;
				}
				if (capacity > oldcapacity) {
					long* newArr = new long[capacity];

					for (long i = 0; i < oldcapacity; i++) {
						newArr[i] = data[i];
					}

					delete[] data;

					data = newArr;
				}

				data[count] = num;
			}
			count++;
		}
		for (long i = 1; i < count; i++) {
			long j = i;
			while (j > 0 && data[j - 1] > data[j]) {
				long temp = data[j];
				data[j] = data[j - 1];
				data[j - 1] = temp;
				j = j - 1;
			}
		}
	
		
	}


	// This is called a destructor. It simply releases the 
	// memory we have been using.
	~SortedArray() {
		delete[] data;
	}

};
std::ostream& operator<<(std::ostream& os, const SortedArray& arr) {
	for (long i = 0; i < arr.count; i++) {
		os << arr.data[i] << " ";
	}

	return os;
}
#endif