#include <igloo/igloo.h>
#include <Array.h>
#include <SortedArray.h>

using namespace igloo;

int main() {
	Context(SortedArrayTest) {
		Spec(NumbersOutOfOrder) {
			SortedArray actual;
			actual.insert(1);
			actual.insert(7);
			actual.insert(5);
			actual.insert(2);

			ResizableArray expected;
			expected.append(1);
			expected.append(2);
			expected.append(5);
			expected.append(7);
			Assert::That(actual, Equals(expected));
		}
		Spec(ReverseOrder) {
			SortedArray actual;
			actual.insert(5);
			actual.insert(4);
			actual.insert(3);
			actual.insert(2);
			actual.insert(1);

			ResizableArray expected;
			expected.append(1);
			expected.append(2);
			expected.append(3);
			expected.append(4);
			expected.append(5);
			Assert::That(actual, Equals(expected));
		}
		Spec(NumbersReversedHalfway) {
			SortedArray actual;
			actual.insert(1);
			actual.insert(2);
			actual.insert(3);
			actual.insert(6);
			actual.insert(5);
			actual.insert(4);

			ResizableArray expected;
			expected.insert(0,1);
			expected.insert(1,2);
			expected.insert(2,3);
			expected.insert(3,4);
			expected.insert(4,5);
			expected.insert(5,6);
			Assert::That(actual, Equals(expected));
		}
		Spec(NegativeNumberInvolved) {
			SortedArray actual;
			actual.insert(-1);
			actual.insert(7);
			actual.insert(5);
			actual.insert(6);

			ResizableArray expected;
			expected.insert(0,-1);
			expected.insert(1,5);
			expected.insert(2,6);
			expected.insert(3,7);
			Assert::That(actual, Equals(expected));
		}
	};
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
