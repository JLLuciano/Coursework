#
# vars.py
#
# This file contains global variables for route-finding search.
#
# David Noelle - Sun Sep 19 23:23:22 PDT 2021
#

# Number of nodes expanded during a search ...
node_expansion_count = 0
