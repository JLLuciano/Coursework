SELECT DISTINCT cust_for, firstyear, secondyear
FROM(SELECT cust_for,
CASE 
    WHEN (dates BETWEEN '1994-01-01' AND '1995-12-31')
    THEN 
    FROM(SELECT cust_for COUNT(l_quantity) AS total,l_shipdate AS dates
FROM nation, supplier, lineitem, customer, orders
WHERE nation.n_nationkey = supplier.s_nationkey
AND nation.n_nationkey != customer.c_nationkey
AND lineitem.l_orderkey = orders.o_orderkey
AND lineitem.l_suppkey = supplier.s_suppkey
AND customer.c_custkey = orders.o_custkey
AND (l_shipdate BETWEEN '1994-01-01' AND '1995-12-31')
GROUP BY n_name),
(SELECT cust_loc, COUNT(l_quantity) AS total2
FROM nation, supplier, lineitem, customer, orders
WHERE nation.n_nationkey != supplier.s_nationkey
AND nation.n_nationkey = customer.c_nationkey
AND lineitem.l_orderkey = orders.o_orderkey
AND lineitem.l_suppkey = supplier.s_suppkey
AND customer.c_custkey = orders.o_custkey
AND (l_shipdate BETWEEN '1994-01-01' AND '1995-12-31')
GROUP BY n_name)
WHERE cust_loc = cust_for
END AS  firstyear
CASE 
    WHEN (dates BETWEEN '1995-01-01' AND '1996-12-31')
    THEN SELECT *
    FROM(SELECT n_name AS cust_for, COUNT(l_quantity) AS total, l_shipdate AS dates
FROM nation, supplier, lineitem, customer, orders
WHERE nation.n_nationkey = supplier.s_nationkey
AND nation.n_nationkey != customer.c_nationkey
AND lineitem.l_orderkey = orders.o_orderkey
AND lineitem.l_suppkey = supplier.s_suppkey
AND customer.c_custkey = orders.o_custkey
AND (l_shipdate BETWEEN '1994-01-01' AND '1995-12-31')
GROUP BY n_name),
(SELECT n_name AS cust_loc, COUNT(l_quantity) AS total2
FROM nation, supplier, lineitem, customer, orders
WHERE nation.n_nationkey != supplier.s_nationkey
AND nation.n_nationkey = customer.c_nationkey
AND lineitem.l_orderkey = orders.o_orderkey
AND lineitem.l_suppkey = supplier.s_suppkey
AND customer.c_custkey = orders.o_custkey
AND (l_shipdate BETWEEN '1994-01-01' AND '1995-12-31')
GROUP BY n_name)
WHERE cust_loc = cust_for
END AS secondyear)
